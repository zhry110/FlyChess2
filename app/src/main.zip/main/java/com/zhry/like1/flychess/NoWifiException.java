package com.zhry.like1.flychess;

/**
 * Created by like1 on 2017/5/15.
 */

public class NoWifiException extends Exception {
    public NoWifiException(String msg)
    {
        super(msg);
    }
}
