package com.zhry.like1.flychess.data;

/**
 * Created by like1 on 2017/5/1.
 */

interface SoundEndCallback {
    void callBack();
}
