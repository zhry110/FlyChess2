package com.zhry.like1.flychess;

import com.zhry.like1.flychess.data.LocalServerMap;
import com.zhry.like1.flychess.data.Map;

/**
 * Created by like1 on 2017/5/23.
 */

public class Schedule extends Thread {
    @Override
    public void run() {
        super.run();
        /*try {
            Thread.sleep(800);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/

    }
}
