package com.zhry.like1.flychess;

import android.content.res.Resources;

import com.zhry.like1.flychess.data.LocalServerMap;
import com.zhry.like1.flychess.data.Map;
import com.zhry.like1.flychess.data.PathProvider;
import com.zhry.like1.flychess.data.Player;
import com.zhry.like1.flychess.view.PathNodeView;

/**
 * Created by like1 on 2017/4/29.
 */

public class GameThread extends Thread {
    private LocalServerMap map;
    public GameThread(int meUid, int users, PathNodeView[] comViews, PathNodeView[] priViews, PathNodeView[] homeViews, Resources res)
    {

    }
    @Override
    public void run() {
        super.run();
    }
}
